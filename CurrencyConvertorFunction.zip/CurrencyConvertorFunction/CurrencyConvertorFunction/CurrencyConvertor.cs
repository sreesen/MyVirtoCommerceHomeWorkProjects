using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using Newtonsoft.Json.Linq;

namespace CurrencyConvertorFunction
{
    public static class CurrencyConvertor
    {
        [FunctionName("CurrencyConvertor")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            string baseCurrency = string.Empty, requiredCurrency = string.Empty;
            double price=0, rate = 1, currencyPrice = 0;

            if (data != null)
            {
                if (data.baseCurrency != null)
                {
                    baseCurrency = data.baseCurrency;
                }
                else
                {
                    baseCurrency = "USD";
                }

                if (data.requiredCurrency != null)
                {
                    requiredCurrency = data.requiredCurrency;
                }
                else
                {
                    requiredCurrency = "EUR";
                }

                if (data.rate != null)
                {
                    rate = Convert.ToDouble(data.rate);
                }
                
                price = Convert.ToDouble(data.price);
            }


            Uri baseUri = new Uri("http://api.exchangeratesapi.io/");
            Uri finalUri = new Uri(baseUri, $"latest?symbols={requiredCurrency}&base={baseCurrency}&access_key=1a0fa5493f455e4b6ca1f66a087e7028");

            using (var client = new HttpClient())
            {
                HttpResponseMessage response = client.GetAsync(finalUri).Result;
                if (response.IsSuccessStatusCode)
                {
                    var respString = await response.Content.ReadAsStringAsync();
                    currencyPrice = Convert.ToDouble(JObject.Parse(respString)["rates"][requiredCurrency]);
                }
            }

            var convertedPrice = price * currencyPrice * rate;

            return new OkObjectResult(convertedPrice);
        }
    }
}
