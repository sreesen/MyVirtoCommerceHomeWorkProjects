﻿using System;
using System.Collections.Generic;
using System.Text;
using VirtoCommerce.OrdersModule.Core.Model;
using VirtoCommerce.Platform.Core.Events;

namespace OrderEvents.DemoModule.Core.Events
{
    public class OrderCompletedEvent : DomainEvent

    {
        public CustomerOrder Order { get; set; }
    }
}
