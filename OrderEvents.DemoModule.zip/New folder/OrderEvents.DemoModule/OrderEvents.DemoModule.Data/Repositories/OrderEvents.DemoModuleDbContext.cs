using EntityFrameworkCore.Triggers;
using Microsoft.EntityFrameworkCore;

namespace OrderEvents.DemoModule.Data.Repositories
{
    public class OrderEventsDemoModuleDbContext : DbContextWithTriggers
    {
        public OrderEventsDemoModuleDbContext(DbContextOptions<OrderEventsDemoModuleDbContext> options)
          : base(options)
        {
        }

        protected OrderEventsDemoModuleDbContext(DbContextOptions options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //        modelBuilder.Entity<MyModuleEntity>().ToTable("MyModule").HasKey(x => x.Id);
            //        modelBuilder.Entity<MyModuleEntity>().Property(x => x.Id).HasMaxLength(128);
            //        base.OnModelCreating(modelBuilder);
        }
    }
}

