angular.module('orderEvents.demoModule')
    .controller('orderEvents.demoModule.helloWorldController', ['$scope', 'orderEvents.demoModule.webApi', function ($scope, api) {
        var blade = $scope.blade;
        blade.title = 'OrderEvents.DemoModule';

        blade.refresh = function () {
            api.get(function (data) {
                blade.title = 'orderEvents.demoModule.blades.hello-world.title';
                blade.data = data.result;
                blade.isLoading = false;
            });
        };

        blade.refresh();
    }]);
