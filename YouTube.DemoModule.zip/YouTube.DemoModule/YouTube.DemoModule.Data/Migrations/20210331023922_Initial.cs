﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace YouTube.DemoModule.Data.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "YoutubeVideo",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 128, nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: true),
                    CreatedBy = table.Column<string>(maxLength: 64, nullable: true),
                    ModifiedBy = table.Column<string>(maxLength: 64, nullable: true),
                    ProductId = table.Column<string>(nullable: true),
                    YoutubeId = table.Column<string>(nullable: true),
                    VideoTitle = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_YoutubeVideo", x => x.Id);
                });
            migrationBuilder.Sql("GO INSERT[dbo].[YoutubeVideo]([Id], [CreatedDate], [ModifiedDate], [CreatedBy], [ModifiedBy], [ProductId], [YoutubeId], [VideoTitle]) VALUES(N'1', CAST(N'2021-03-29T10:25:00.0000000' AS DateTime2), CAST(N'2021-03-29T10:25:00.0000000' AS DateTime2), N'sreesen.ss', N'sreesen.ss', N'1', N'testUrl', N'Virto Video')");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "YoutubeVideo");
        }
    }
}
