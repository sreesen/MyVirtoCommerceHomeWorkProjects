﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VirtoCommerce.Platform.Core.Common;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Data.Repositories
{
    public interface IYoutubeRepository : IRepository
    {
        IQueryable<YoutubeVideo> YoutubeVideos { get; }
    }
}
