using EntityFrameworkCore.Triggers;
using Microsoft.EntityFrameworkCore;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Data.Repositories
{
    public class YouTubeDemoModuleDbContext : DbContextWithTriggers
    {
        public YouTubeDemoModuleDbContext(DbContextOptions<YouTubeDemoModuleDbContext> options)
          : base(options)
        {
        }

        protected YouTubeDemoModuleDbContext(DbContextOptions options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<YoutubeVideo>().ToTable("YoutubeVideo").HasKey(x => x.Id);
            modelBuilder.Entity<YoutubeVideo>().Property(x => x.Id).HasMaxLength(128);
            base.OnModelCreating(modelBuilder);
        }
    }
}

