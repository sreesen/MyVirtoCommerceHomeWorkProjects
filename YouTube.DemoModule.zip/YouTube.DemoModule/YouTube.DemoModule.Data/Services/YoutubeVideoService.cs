﻿using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Core.Services;
using YouTube.DemoModule.Data.Repositories;
using System.Linq;
using System.Threading.Tasks;
using VirtoCommerce.Platform.Core.Events;
using YouTube.DemoModule.Core.Events;

namespace YouTube.DemoModule.Data.Services
{
    public class YoutubeVideoService : IYoutubeVideoService
    {
        private readonly IYoutubeRepository _repository;

        private readonly IEventPublisher _eventPublisher;
        public YoutubeVideoService(IYoutubeRepository repository, IEventPublisher eventPublisher)
        {
            _repository = repository;
            _eventPublisher = eventPublisher;
        }

        public Task<YoutubeVideoResult> GetVideos()
        {
            var result = new YoutubeVideoResult
            {
                TotalCount = _repository.YoutubeVideos.Count(),
                Results = _repository.YoutubeVideos.ToList()
            };

            return Task.FromResult(result);
        }

        public async Task<YoutubeVideo> Update(YoutubeVideo video)
        {
            //TODO: need to save ..
            //trigger event

           await _eventPublisher.Publish(new YoutubeVideoChangedEvent { Video = video });
            return video;
        }
    }
}
