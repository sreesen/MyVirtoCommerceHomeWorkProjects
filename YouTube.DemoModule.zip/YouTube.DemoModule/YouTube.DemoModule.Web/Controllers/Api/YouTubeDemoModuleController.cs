using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using YouTube.DemoModule.Core;
using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Core.Services;

namespace YouTube.DemoModule.Web.Controllers.Api
{
    [Route("api/YouTubeDemoModule")]
    public class YouTubeDemoModuleController : Controller
    {
        private readonly IYoutubeVideoService _service;
        public YouTubeDemoModuleController(IYoutubeVideoService service)
        {
            _service = service;
        }

        // GET: api/YouTubeDemoModule
        /// <summary>
        /// Get message
        /// </summary>
        /// <remarks>Return "Hello world!" message</remarks>
        [HttpGet]
        [Route("")]
        [Authorize(ModuleConstants.Security.Permissions.Read)]
        public ActionResult<string> Get()
        {
            return Ok(new { result = "Hello world!" });
        }

        [HttpGet]
        [Route("GetVideos")]
        [Authorize(ModuleConstants.Security.Permissions.Read)]
        public Task<YoutubeVideoResult> GetVideos()
        {
            return _service.GetVideos();
        }

        [HttpPost]
        [Route("Update")]
        [Authorize(ModuleConstants.Security.Permissions.Update)]
        public Task<YoutubeVideo> Update([FromBody] YoutubeVideo video)
        {
            return _service.Update(video);
        }

    }
}
