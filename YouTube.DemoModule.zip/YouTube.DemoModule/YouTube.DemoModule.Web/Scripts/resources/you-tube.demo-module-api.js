angular.module('youTube.demoModule')
    .factory('youTube.demoModule.webApi', ['$resource', function ($resource) {
        return $resource('api/YouTubeDemoModule');
}]);
