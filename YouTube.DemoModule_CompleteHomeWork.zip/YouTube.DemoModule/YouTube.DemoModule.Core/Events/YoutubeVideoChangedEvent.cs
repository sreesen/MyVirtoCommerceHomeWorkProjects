﻿using System;
using System.Collections.Generic;
using System.Text;
using VirtoCommerce.Platform.Core.Events;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Core.Events
{
    public class YoutubeVideoChangedEvent: GenericChangedEntryEvent<YoutubeVideo>
    {
        public YoutubeVideoChangedEvent(IEnumerable<GenericChangedEntry<YoutubeVideo>> changedEntries) : base(changedEntries)
        {
        }
    }
}
