﻿using System;
using System.Collections.Generic;
using System.Text;
using VirtoCommerce.Platform.Core.Common;

namespace YouTube.DemoModule.Core.Models
{
    public class YoutubeVideoSearchCriteria: SearchCriteriaBase
    {
        public string SearchField { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
