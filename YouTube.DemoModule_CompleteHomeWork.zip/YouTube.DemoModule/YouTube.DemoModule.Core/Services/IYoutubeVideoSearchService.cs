﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VirtoCommerce.Platform.Core.Events;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Core.Services
{
   public interface IYoutubeVideoSearchService
    {
        Task<YoutubeVideoSearchResult> GetYoutubeVideosAsync(YoutubeVideoSearchCriteria criteria);
    }
}
