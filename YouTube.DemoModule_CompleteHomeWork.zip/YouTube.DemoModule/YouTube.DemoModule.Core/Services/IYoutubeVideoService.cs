﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Core.Services
{
    public interface IYoutubeVideoService
    {
        Task<YoutubeVideo[]> GetByIdsAsync(string[] Ids);
        Task SaveYoutubeVideosAsync(YoutubeVideo[] youtubeVideo);
        Task DeleteYoutubeVideosAsync(string[] ids);
    }
}
