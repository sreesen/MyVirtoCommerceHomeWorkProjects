﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YouTube.DemoModule.Data.Models
{
    public static class SearchFieldTypes
    {
        public const string ProductId = "ProductId";
        public const string ProductName = "ProductName";
        public const string YoutubeId = "YoutubeId";
        public const string VideoTitle = "VideoTitle";
    }
}
