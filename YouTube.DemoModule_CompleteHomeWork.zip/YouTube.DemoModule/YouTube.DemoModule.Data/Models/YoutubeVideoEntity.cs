﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using VirtoCommerce.Platform.Core.Common;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Data.Models
{
    public class YoutubeVideoEntity : AuditableEntity
    {
        [Required]
        [StringLength(128)]
        public string ProductId { get; set; }

        public string ProductName { get; set; }
        [Required]
        [StringLength(128)]
        public string YoutubeId { get; set; }
        public string VideoTitle { get; set; }


        public virtual YoutubeVideo ToModel(YoutubeVideo youtubeVideo)
        {
            if (youtubeVideo == null)
                throw new ArgumentNullException(nameof(youtubeVideo));

            youtubeVideo.Id = Id;
            youtubeVideo.CreatedBy = CreatedBy;
            youtubeVideo.CreatedDate = CreatedDate;
            youtubeVideo.ModifiedBy = ModifiedBy;
            youtubeVideo.ModifiedDate = ModifiedDate;

            youtubeVideo.ProductId = ProductId;
            youtubeVideo.ProductName = ProductName;

            youtubeVideo.YoutubeId = YoutubeId;
            youtubeVideo.VideoTitle = VideoTitle;

            return youtubeVideo;
        }

        public virtual YoutubeVideoEntity FromModel(YoutubeVideo youtubeVideo, PrimaryKeyResolvingMap pkMap)
        {
            if (youtubeVideo == null)
                throw new ArgumentNullException(nameof(youtubeVideo));

            pkMap.AddPair(youtubeVideo, this);

            Id = youtubeVideo.Id;
            CreatedBy = youtubeVideo.CreatedBy;
            CreatedDate = youtubeVideo.CreatedDate;
            ModifiedBy = youtubeVideo.ModifiedBy;
            ModifiedDate = youtubeVideo.ModifiedDate;

            ProductId = youtubeVideo.ProductId;
            ProductName = youtubeVideo.ProductName;

            YoutubeId = youtubeVideo.YoutubeId;
            VideoTitle = youtubeVideo.VideoTitle;

            return this;
        }

        public virtual void Patch(YoutubeVideoEntity target)
        {
            if (target == null)
                throw new ArgumentNullException(nameof(target));

            target.ProductId = ProductId;
            target.ProductName = ProductName;

            target.YoutubeId = YoutubeId;
            target.VideoTitle = VideoTitle;
        }
    }
}
