﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VirtoCommerce.Platform.Core.Common;
using YouTube.DemoModule.Data.Models;

namespace YouTube.DemoModule.Data.Repositories
{
    public interface IYoutubeVideoRepository : IRepository
    {
        IQueryable<YoutubeVideoEntity> YoutubeVideos { get; }

        Task<YoutubeVideoEntity[]> GetByIdsAsync(IEnumerable<string> ids);
        Task DeleteYoutubeVideosAsync(string[] ids);
    }
}
