using EntityFrameworkCore.Triggers;
using Microsoft.EntityFrameworkCore;
using YouTube.DemoModule.Data.Models;

namespace YouTube.DemoModule.Data.Repositories
{
    public class YouTubeDemoModuleDbContext : DbContextWithTriggers
    {
        public YouTubeDemoModuleDbContext(DbContextOptions<YouTubeDemoModuleDbContext> options)
          : base(options)
        {
        }

        protected YouTubeDemoModuleDbContext(DbContextOptions options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<YoutubeVideoEntity>().ToTable("YoutubeVideo").HasKey(x => x.Id);
            modelBuilder.Entity<YoutubeVideoEntity>().Property(x => x.Id).HasMaxLength(128);
            modelBuilder.Entity<YoutubeVideoEntity>().Property(x => x.Id).HasMaxLength(128).ValueGeneratedOnAdd();
            base.OnModelCreating(modelBuilder);
        }
    }
}

