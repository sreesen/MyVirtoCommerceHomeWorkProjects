﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using VirtoCommerce.Platform.Data.Infrastructure;
using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Data.Models;

namespace YouTube.DemoModule.Data.Repositories
{
    public class YoutubeRepository : DbContextRepositoryBase<YouTubeDemoModuleDbContext>, IYoutubeVideoRepository
    {
        public YoutubeRepository(YouTubeDemoModuleDbContext context) : base(context)
        {

        }

        public IQueryable<YoutubeVideoEntity> YoutubeVideos => DbContext.Set<YoutubeVideoEntity>();

        public Task<YoutubeVideoEntity[]> GetByIdsAsync(IEnumerable<string> ids)
        {
            return YoutubeVideos.Where(x => ids.Contains(x.Id)).ToArrayAsync();
        }

        public async Task DeleteYoutubeVideosAsync(string[] ids)
        {
            var items = await GetByIdsAsync(ids);
            foreach (var item in items)
            {
                Remove(item);
            }
        }
    }
}
