﻿using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Core.Services;
using YouTube.DemoModule.Data.Repositories;
using System.Linq;
using System.Threading.Tasks;
using System;
using VirtoCommerce.Platform.Core.Caching;
using Microsoft.Extensions.Caching.Memory;
using YouTube.DemoModule.Data.Caching;
using VirtoCommerce.Platform.Core.Common;
using YouTube.DemoModule.Data.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;

namespace YouTube.DemoModule.Data.Services
{
    public class YoutubeVideoSearchService : IYoutubeVideoSearchService
    {
        private readonly Func<IYoutubeVideoRepository> _repositoryFactory;
        private readonly IYoutubeVideoService _youtubeVideoService;
        private readonly IPlatformMemoryCache _platformMemoryCache;
        public YoutubeVideoSearchService(Func<IYoutubeVideoRepository> repositoryFactory, IYoutubeVideoService youtubeVideoService, IPlatformMemoryCache platformMemoryCache)
        {
            _repositoryFactory = repositoryFactory;
            _youtubeVideoService = youtubeVideoService;
            _platformMemoryCache = platformMemoryCache;
        }

        public async Task<YoutubeVideoSearchResult> GetYoutubeVideosAsync(YoutubeVideoSearchCriteria criteria)
        {
            var cacheKey = CacheKey.With(GetType(), nameof(GetYoutubeVideosAsync), criteria.GetCacheKey());
            return await _platformMemoryCache.GetOrCreateExclusiveAsync(cacheKey, async (cacheEntry) =>
            {
                cacheEntry.AddExpirationToken(YoutubeVideoCacheRegion.CreateChangeToken());
                var result = AbstractTypeFactory<YoutubeVideoSearchResult>.TryCreateInstance();

                using (var repository = _repositoryFactory())
                {
                    var query = BuildQuery(repository, criteria);
                    var sortInfos = BuildSortExpression(criteria);

                    result.TotalCount = await query.CountAsync();

                    if (criteria.Take > 0)
                    {
                        var youtubeVideoIds = await query.OrderBySortInfos(sortInfos).Skip(criteria.Skip)
                            .Take(criteria.Take)
                            .Select(x => x.Id)
                            .ToArrayAsync();

                        var priorResults = await _youtubeVideoService.GetByIdsAsync(youtubeVideoIds);
                        //TODO warning EF1001: Microsoft.EntityFrameworkCore.Internal.EnumerableExtensions is an internal API that supports the Entity Framework Core infrastructure and not subject to the same compatibility standards as public APIs.
                        result.Results = priorResults.OrderBy(x => youtubeVideoIds.IndexOf(x.Id)).ToList();
                    }

                    return result;
                }
            });

        }

        protected virtual IQueryable<YoutubeVideoEntity> BuildQuery(IYoutubeVideoRepository repository,
            YoutubeVideoSearchCriteria criteria)
        {
            var query = repository.YoutubeVideos;

            if (!criteria.SearchField.IsNullOrEmpty()&& !criteria.SearchPhrase.IsNullOrEmpty())
            {
                switch(criteria.SearchField)
                {
                    case SearchFieldTypes.ProductId:
                        query = query.Where(x => x.ProductId.Contains(criteria.SearchPhrase));
                        break;
                    case SearchFieldTypes.ProductName:
                        query = query.Where(x => x.ProductName.Contains(criteria.SearchPhrase));
                        break;
                    case SearchFieldTypes.YoutubeId:
                        query = query.Where(x => x.YoutubeId.Contains(criteria.SearchPhrase));
                        break;
                    case SearchFieldTypes.VideoTitle:
                        query = query.Where(x => x.VideoTitle.Contains(criteria.SearchPhrase));
                        break;
                }
            }
             
            if (criteria.ModifiedDate.HasValue)
            {
                query = query.Where(x => x.ModifiedDate >= criteria.ModifiedDate.Value);
            }

            return query;
        }

        protected virtual IList<SortInfo> BuildSortExpression(YoutubeVideoSearchCriteria criteria)
        {
            var sortInfos = criteria.SortInfos;
            if (sortInfos.IsNullOrEmpty())
            {
                sortInfos = new[] {
                    new SortInfo { SortColumn = nameof(YoutubeVideo.CreatedDate), SortDirection = SortDirection.Descending },
                };
            }
            return sortInfos;
        }

    }
}
