﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using VirtoCommerce.Platform.Caching;
using VirtoCommerce.Platform.Core.Caching;
using VirtoCommerce.Platform.Core.Common;
using VirtoCommerce.Platform.Core.Events;
using VirtoCommerce.Platform.Data.Infrastructure;
using YouTube.DemoModule.Core.Events;
using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Core.Services;
using YouTube.DemoModule.Data.Caching;
using YouTube.DemoModule.Data.Models;
using YouTube.DemoModule.Data.Repositories;

namespace YouTube.DemoModule.Data.Services
{
    public class YoutubeVideoService : IYoutubeVideoService
    {
        private readonly IPlatformMemoryCache _platformMemoryCache;
        private readonly Func<IYoutubeVideoRepository> _repositoryFactory;
        private readonly IEventPublisher _eventPublisher;
        public YoutubeVideoService(Func<IYoutubeVideoRepository> repositoryFactory, IEventPublisher eventPublisher, IPlatformMemoryCache platformMemoryCache)
        {
            _repositoryFactory = repositoryFactory;
            _eventPublisher = eventPublisher;
            _platformMemoryCache = platformMemoryCache;
        }

        public async Task<YoutubeVideo[]> GetByIdsAsync(string[] productIds)
        {
            var cacheKey = CacheKey.With(GetType(), nameof(GetByIdsAsync), string.Join("-", productIds));
            return await _platformMemoryCache.GetOrCreateExclusiveAsync(cacheKey, async (cacheEntry) =>
            {
                cacheEntry.AddExpirationToken(YoutubeVideoCacheRegion.CreateChangeToken());
                using (var repository = _repositoryFactory())
                {
                    repository.DisableChangesTracking();

                    var videos = await repository.GetByIdsAsync(productIds);

                    return videos.Select(x => x.ToModel(AbstractTypeFactory<YoutubeVideo>.TryCreateInstance())).ToArray();
                }
            });
        }

        public async Task SaveYoutubeVideosAsync(YoutubeVideo[] youtubeVideo)
        {

            using (var repository = _repositoryFactory())
            {
                var pkMap = new PrimaryKeyResolvingMap();
                var changedEntries = new List<GenericChangedEntry<YoutubeVideo>>();

                var alreadyExistEntities = await repository.GetByIdsAsync(youtubeVideo.Where(m => !m.IsTransient()).Select(x => x.Id));
                foreach (var video in youtubeVideo)
                {
                    var sourceEntity = AbstractTypeFactory<YoutubeVideoEntity>.TryCreateInstance().FromModel(video, pkMap);
                    var targetEntity = alreadyExistEntities.FirstOrDefault(x => x.Id == sourceEntity.Id);
                    if (targetEntity != null)
                    {
                        changedEntries.Add(new GenericChangedEntry<YoutubeVideo>(video, targetEntity.ToModel(AbstractTypeFactory<YoutubeVideo>.TryCreateInstance()), EntryState.Modified));
                        sourceEntity.Patch(targetEntity);
                    }
                    else
                    {
                        repository.Add(sourceEntity);
                        changedEntries.Add(new GenericChangedEntry<YoutubeVideo>(video, EntryState.Added));
                    }
                }


                await repository.UnitOfWork.CommitAsync();
                pkMap.ResolvePrimaryKeys();

                ClearCache();

                await _eventPublisher.Publish(new YoutubeVideoChangedEvent(changedEntries));

            }
        }

        public async Task DeleteYoutubeVideosAsync(string[] ids)
        {
            using (var repository = _repositoryFactory())
            {
                var youtubeVideos = await GetByIdsAsync(ids);

                var changedEntries = youtubeVideos.Select(x => new GenericChangedEntry<YoutubeVideo>(x, EntryState.Deleted)).ToArray();

                await repository.DeleteYoutubeVideosAsync(ids);
                await repository.UnitOfWork.CommitAsync();

                ClearCache();

                await _eventPublisher.Publish(new YoutubeVideoChangedEvent(changedEntries));
            }
        }

        protected virtual void ClearCache()
        {
            YoutubeVideoCacheRegion.ExpireRegion();
        }
    }
}
