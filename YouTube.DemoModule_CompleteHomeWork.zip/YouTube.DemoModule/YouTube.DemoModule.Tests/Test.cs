using Xunit;

namespace YouTube.DemoModule.Tests
{
    public class Test
    {
        public Test()
        {
        }

        [Fact]
        public void Run_Test()
        {
            Assert.Equal(0, 0);
        }
    }
}
