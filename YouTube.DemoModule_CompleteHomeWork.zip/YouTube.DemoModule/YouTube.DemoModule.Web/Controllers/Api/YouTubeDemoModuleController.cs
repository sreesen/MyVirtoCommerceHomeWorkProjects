using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using YouTube.DemoModule.Core;
using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Core.Services;

namespace YouTube.DemoModule.Web.Controllers.Api
{
    [Route("api/YouTubeDemoModule")]
    [ApiController]
    public class YouTubeDemoModuleController : Controller
    {
        private readonly IYoutubeVideoSearchService _videoSearchService;
        private readonly IYoutubeVideoService _videoService;
        public YouTubeDemoModuleController(IYoutubeVideoSearchService videoSearchService, IYoutubeVideoService videoService)
        {
            _videoSearchService = videoSearchService;
            _videoService = videoService;
        }

        /// <summary>
        /// Return list of youtube videos with product name
        /// </summary>
        [HttpPost]
        [Route("getYoutubeVideos")]
        [Authorize(ModuleConstants.Security.Permissions.YoutubeVideoRead)]
        public async Task<ActionResult<YoutubeVideoSearchResult>> GetYoutubeVideos([FromBody] YoutubeVideoSearchCriteria criteria)
        {
            var videoList = await _videoSearchService.GetYoutubeVideosAsync(criteria);

            var retVal = new YoutubeVideoSearchResult { Results = videoList.Results, TotalCount = videoList.TotalCount };
            return Ok(retVal);
        }

        /// <summary>
        /// Add new youtube video
        /// </summary>
        [HttpPost]
        [Route("addYoutubeVideo")]
        [Authorize(ModuleConstants.Security.Permissions.YoutubeVideoCreate)]
        public async Task<ActionResult<YoutubeVideo>> AddYoutubeVideo([FromBody] YoutubeVideo video)
        {
            await _videoService.SaveYoutubeVideosAsync(new[] { video });
            return Ok(video);
        }

        /// <summary>
        /// Delete Youtube Viedo by IDs
        /// </summary>
        /// <param name="ids">IDs</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("deleteYoutubeVideo")]
        [Authorize(ModuleConstants.Security.Permissions.YoutubeVideoDelete)]
        [ProducesResponseType(typeof(void), StatusCodes.Status204NoContent)]
        public async Task<ActionResult> Delete([FromQuery] string[] ids)
        {
            await _videoService.DeleteYoutubeVideosAsync(ids);
            return NoContent();
        }

        /// <summary>
        /// Gets Youtube Video by product id.
        /// </summary>
        /// <remarks>Gets Youtube Video by product id with full information loaded</remarks>
        /// <param name="id">The Product id.</param>
        [HttpGet]
        [Route("{id}")]
        [Authorize(ModuleConstants.Security.Permissions.YoutubeVideoRead)]
        public async Task<ActionResult<YoutubeVideo[]>> GetVideo(string id)
        {
            var videos = await _videoService.GetByIdsAsync(new[] { id });

            if (videos == null)
            {
                return NotFound();
            }

            return Ok(videos);
        }
    }
}
