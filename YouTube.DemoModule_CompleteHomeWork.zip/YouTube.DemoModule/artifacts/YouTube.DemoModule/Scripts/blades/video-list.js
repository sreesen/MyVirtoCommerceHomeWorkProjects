angular.module('youTube.demoModule')
    .controller('youTube.demoModule.videoListController', ['$scope', 'platformWebApp.dialogService', 'youTube.demoModule.WebApi', 'platformWebApp.bladeUtils', 'uiGridConstants', 'platformWebApp.uiGridHelper', 'platformWebApp.authService',
        function ($scope, dialogService, videoApi, bladeUtils, uiGridConstants, uiGridHelper, authService) {
            $scope.uiGridConstants = uiGridConstants;

            var blade = $scope.blade;
            blade.title = 'youTube.demoModule.title';
            var bladeNavigationService = bladeUtils.bladeNavigationService;

            blade.refresh = function () {
                blade.isLoading = true;
                var searchField = filter.searchFieldObj ? filter.searchFieldObj.name : null;

                videoApi.search(angular.extend(filter, {
                    searchPhrase: filter.keyword ? filter.keyword : undefined,
                    searchField,
                    sort: uiGridHelper.getSortExpression($scope),
                    skip: ($scope.pageSettings.currentPage - 1) * $scope.pageSettings.itemsPerPageCount,
                    take: $scope.pageSettings.itemsPerPageCount
                }), function (data) {
                    blade.isLoading = false;
                    $scope.pageSettings.totalItems = data.totalCount;
                    blade.currentEntities = data.results;
                });
            };


            blade.selectNode = function (data) {

            };

            function addNewVideo() {
                $scope.selectedNodeId = null;

                var newBlade = {
                    id: 'addYoutubeVideo',
                    currentEntity: {},
                    controller: 'youTube.demoModule.addYoutubeVideoController',
                    template: 'Modules/$(youTube.demoModule)/Scripts/blades/addVideo.html'
                };
                bladeNavigationService.showBlade(newBlade, blade);
            }

            $scope.deleteList = function (list) {
                var dialog = {
                    id: "confirmDeleteItem",
                    title: "youTube.demoModule.blades.video-list.dialogs.video-delete.title",
                    message: "youTube.demoModule.blades.video-list.dialogs.video-delete.message",
                    callback: function (remove) {
                        if (remove) {
                            $scope.isLoading = true;
                            closeChildrenBlades();

                            var itemIds = _.pluck(list, 'id');
                            videoApi.delete({ ids: itemIds }, function (data, headers) {
                                blade.refresh();
                            },
                                function (error) {
                                    bladeNavigationService.setError('Error ' + error.status, blade);
                                });

                        }
                    }
                };
                dialogService.showConfirmationDialog(dialog);
            };

            function closeChildrenBlades() {
                angular.forEach(blade.childrenBlades.slice(), function (child) {
                    bladeNavigationService.closeBlade(child);
                });
            }

            blade.headIcon = 'fab fa-youtube';

            blade.toolbarCommands = [
                {
                    name: "platform.commands.refresh", icon: 'fa fa-refresh',
                    executeMethod: blade.refresh,
                    canExecuteMethod: function () {
                        return true;
                    }
                },
                {
                    name: "platform.commands.add", icon: 'fa fa-plus',
                    executeMethod: addNewVideo,
                    canExecuteMethod: function () {
                        return true;
                    },
                    permission: 'youTubeDemoModule:create'
                }
            ];

            if (!blade.hideDelete) {
                blade.toolbarCommands.push({
                    name: "platform.commands.delete", icon: 'fas fa-trash-alt',
                    executeMethod: function () {
                        $scope.deleteList($scope.gridApi.selection.getSelectedRows());
                    },
                    canExecuteMethod: function () {
                        return $scope.gridApi && _.any($scope.gridApi.selection.getSelectedRows());
                    },
                    permission: 'youTubeDemoModule:delete'
                });
            }

            $scope.searchFieldList = [
                {
                    name: "ProductId",
                    value: 0
                },
                {
                    name: "ProductName",
                    value: 1
                },
                {
                    name: "YoutubeId",
                    value: 2
                },
                {
                    name: "VideoTitle",
                    value: 3
                }
            ];

            // simple and advanced filtering
            var filter = $scope.filter = blade.filter || {};

            filter.criteriaChanged = function () {
                if ($scope.pageSettings.currentPage > 1) {
                    $scope.pageSettings.currentPage = 1;
                } else {
                    blade.refresh();
                }
            };

            // ui-grid
            $scope.setGridOptions = function (gridOptions) {
                uiGridHelper.initialize($scope, gridOptions, function (gridApi) {
                    uiGridHelper.bindRefreshOnSortChanged($scope);
                });
                bladeUtils.initializePagination($scope);
            };

        }]);
