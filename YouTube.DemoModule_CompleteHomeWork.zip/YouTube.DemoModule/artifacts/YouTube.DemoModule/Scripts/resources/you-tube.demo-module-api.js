angular.module('youTube.demoModule')
    .factory('youTube.demoModule.WebApi', ['$resource', function ($resource) {
        return $resource('api/YouTubeDemoModule', {}, {
            search: { method: 'POST', url: 'api/YouTubeDemoModule/getYoutubeVideos' },
            add: { method: 'POST', url: 'api/YouTubeDemoModule/addYoutubeVideo' },
        });
    }
]);
